package pig;

import craps.CrapsGame;

public class GameApp {

    public static void main(String[] args) {

        PigGame game1 = new PigGame();

        game1.play();

    }
}

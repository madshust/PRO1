package craps_extended;

public class GameApp {
    public static void main(String[] args) {
        CrapsGame game1 = new CrapsGame();
        game1.play();
    }
}
